module.exports = {
    getPaintings: (dbConnection, callback) => {
        callback();
    },
}