const dbConnection = '';
const { getPaintings } = require('../models/home')

module.exports.home = (app, req, res) => {
    console.log('home');
    getPaintings(dbConnection, (error,result) =>{
        res.render('home');
    })
}