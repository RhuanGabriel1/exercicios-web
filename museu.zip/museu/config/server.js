console.log('[Config] Server');
const express = require("express")

const app = express();
const port = process.env.PORT || 3000;
let expressSession = require('express-session')

app.set('view engine', 'ejs');
app.set('views', './app/views');
console.log(__dirname);
app.use(express.static('./public'));


app.use(express.json())
app.use(express.urlencoded({extended: true}));

app.use(expressSession({
	secret: 'ViscondedeSabugosa' ,//pode ser qualquer string,
	resave: false,
	saveUninitialized: false,

}));

app.listen(port, function(){
	console.log('Servidor rodando com express na porta', port);
});



module.exports = app;