const { addUserController } = require('../controllers/users');
const { check, validationResult } = require('express-validator');

module.exports = {


    insertUser: (app) => {
        app.get('/inserirusuario', function (req, res) {
            res.render('insertUser.ejs', { user: {}, errors: {} });
        });
},
    saveUser: (app) => {
        app.post('/salvarusuario', 
        [

            check('email').isEmail().normalizeEmail().withMessage('Email deve ser valido!'),
            check('password').isLength({ min: 5, max: 20 }).withMessage('Password deve ter no minimo 5 e no maximo 20 caracteres'),
            check('confirmPassword').custom((value, { req }) =>
            
            {
                console.log(value);
                if( value != req.body.password){
                    throw new Error('As senhas digitadas nao sao iguais! ');
                }
                return true;

            })], (req, res) => {
            const validation = validationResult(req);

            //pega o que digitou 
            const user = req.body
            console.log("rota salvando usuario");
            if (!validation.isEmpty()) {
                const errors = validation.array();
                res.render('insertUser.ejs', { errors: errors, user: user});

            } else{
                console.log('aqui vou incluir o usuario no banco');
                    addUserController(app, req, res);
                }
        });
}

}




