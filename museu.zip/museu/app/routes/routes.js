const { tarsila } = require('../controllers/tarsila');
const { portinari } = require('../controllers/portinari');
const { obradearte } = require('../controllers/obradearte');
const { home, addPaintingController, changeFormPaintingController, changePaintingController } = require('../controllers/home');
const { check, validationResult } = require('express-validator');

module.exports = {
    home: (app) => {
        app.get('/', (req, res) => {
            //res.render("home.ejs");
            home(app, req, res);
        });
    },

    tarsila: (app) => {
        app.get('/tarsila', (req, res) => {
            tarsila(app, req, res);
        });
    },

    portinari: (app) => {
        app.get('/portinari', (req, res) => {
            portinari(app, req, res);

        });
    },
    getPainting: (app) => {
        app.get('/obradearte', (req, res) => {
            let id = req.params.idobra
            console.log(id)
            obradearte(app, req, res);

        })
    },
    changePainting: (app) => {
        app.get('/alterarobradearte', (req, res) => {
          changeFormPaintingController(app, req, res);
        });
      },

    insertPainting: (app) => {
        app.get('/inserirobra', function (req, res) {
            res.render('insertPainting.ejs', { errors: {}, painting: {} });
        });

    },
    insertPainting: (app) => {
        app.get('/inserirobra', function (req, res) {
          res.render('insertPainting.ejs', { painting: {}, errors: {} });
        });
      },
    savePainting: (app) => {
        app.post('/obra/salvar', [

            check('nome').isLength({ min: 1, max: 100 }).withMessage('Nome deve ter no mínimo 5 caracteres'),
            check('descricao').isLength({ min: 1, max: 250 }).withMessage('descrição deve ter no mínimo 5 caracteres'),
            check('ano').isLength({ min: 0, max: 2100 }).isNumeric().withMessage('Ano deve ser numérico e conter 4 números.'),
            check('artista').isLength({min: 1, max: 100 }).withMessage('Artista deve ter no mínimo 5 caracteres'),
            check('urlimagem').isURL().withMessage('URL da imagem deve conter um link')


        ], (req, res) => {
            const err = validationResult(req);
            painting = req.body;
            let operation = req.query.op
            console.log("rota salvar");
            if (!err.isEmpty()) {
                let errors = err.array();
                res.render('insertPainting.ejs', { errors: errors, painting: painting});
                return;
            } else{
                console.log(operation);
                switch (operation) {
                  case 'i': addPaintingController(app, req, res);
                  case 'c': changePaintingController(app, req, res);
                  default: console.log('Operação não prevista');
                }
            }
        });
        
    }
}








