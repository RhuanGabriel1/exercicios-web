
const dbConnection = require('../../config/dbConnection');
const { getPaintings, addPainting, getPainting, changePainting} = require('../models/home')

module.exports.home = (app, req, res) => {
    console.log('[Controller Home]');
    dbConn = dbConnection();  
        getPaintings(dbConn, (error, result) =>{
          console.log(error);
           res.render('home.ejs', { paintings: result}); 
        })
    
}
module.exports.addPaintingController = (app, req, res) => {
    console.log('[Controller Home Add Painting]');
    let painting = req.body;
    console.log(painting);
    dbConn = dbConnection();
    addPainting(painting, dbConn, (error, result) => {
      console.log(error);
      res.redirect('/')

    });
  }
  module.exports.changePaintingController = (app, req, res) => {
    console.log('Change Painting Controller', req.query);
    let painting = req.body;
    painting.id = req.query.id;
    console.log(painting);
    dbConn = dbConnection();
    changePainting(painting, dbConn, (error, result) => {
      console.log(error);
      res.redirect('/')
    });
  };
  
  module.exports.getPaintingController = (app, req, res) => {
    console.log('[Controller Home Get Painting]');
    let paintingId = req.query.idobra;
    console.log(paintingId);
    console.log(paintingId);
    dbConn = dbConnection();
    getPainting(paintingId, dbConn, (error, result) => {
      console.log(error);
      res.render('home.ejs', { painting: result });
    });
  };
  
  module.exports.changeFormPaintingController = (app, req, res) => {
    console.log('Formulario para alteração da obra');
    let paintingId = req.query.idobra;
    dbConn = dbConnection();
    getPainting(paintingId, dbConn, (error, result) => {
      console.log(error);
      let painting = result[0];
      res.render('insertPainting', { painting: painting, errors: error , op: 'c'});
    });
  };