
const dbConnection = require('../../config/dbConnection');
const { getPainting } = require('../models/obradearte')

module.exports.obradearte = (app, req, res) => {
    console.log('[Controller obra unica]');
     let id = req.query.idobra;
     console.log("id",id);
    const db = dbConnection();
        getPainting(db, id, (error, result) =>{
            console.log(result,error);
           res.render('obradearte.ejs', { painting: result}); 
        })
        
  
}