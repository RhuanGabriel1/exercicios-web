const dbConnection = require('../../config/dbConnection')
const { addUser } = require ('../models/users')

module.exports.addUserController = (app, req, res) => {
    console.log('[controller de adicionando usuario]');
    let user = req.body;
    console.log(user);
    dbConn = dbConnection();
    addUser(user, dbConn, (error, result) => {
      if(error){
        console.log(error);
        res.end('Erro ao cadastrar usuario')
      }
      else{ 
        res.end('Usuario cadastrado com sucesso!');
      }
    });
}