const dbConnection = require('../../config/dbConnection');
const crypto = require('crypto');
const { addUser, authUser } = require('../models/users');

module.exports.addUserController = (app, req, res) => {
    console.log('[Controller User Add User]');
    let user = req.body;
    console.log(user);
    let passwordCrypto = crypto.createHash('md5').update(user.password).digest('hex');
    console.log(passwordCrypto);
    user.password = passwordCrypto;
    dbConn = dbConnection();
    addUser(user, dbConn, (error, result) => {
        if (error) {
            console.log(error);
            res.end('Erro ao cadastrar usuario !');
        } else {
            res.end('Usuario cadastrado com sucesso !');
        }
    });
};


module.exports.authUserController = (app, req, res) => {
  console.log('[Controller User Auth User]');
  let user = req.body;
  let passwordCrypto = crypto.createHash('md5').update(user.password).digest('hex');
  user.password = passwordCrypto;
  dbConn = dbConnection();
  authUser(user, dbConn, (error, result) => {
      if (error) {
          console.log(error);
          res.end('Erro ao autenticar usuario !');
      } else {
          console.log(result);
          if(result.length > 0){
              res.end('Usuario autenticado com sucesso !');
          } else {
              res.end('Usuario não autenticado !');
          }
      }
  });
};