module.exports = {
    getPaintings: (dbConnection, callback) => {
        const sql = 'select * from paintings;';
        dbConnection.query(sql, callback);
    },

    addPainting: (painting, dbConnection, callback) => {
        const sql = `insert into paintings (nome, artista, ano, urlimagem, descricao) VALUES ("${painting.nome}", "${painting.artista}", ${painting.ano}, "${painting.urlimagem}", "${painting.descricao}");`
        console.log(sql);
        dbConnection.query(sql, callback);
    },
    getPainting: (paintingId, dbConnection, callback) => {
        const sql = `select * from paintings where idobra='${paintingId}';`;
        console.log("sql:",sql);
        dbConnection.query(sql, callback);
    },
    changePainting: (painting, dbConnection, callback) => {
        const sql = `update paintings set nome = "${painting.nome}" where idobra=${painting.id};`;
        console.log("sql:",sql, painting);
        dbConnection.query(sql, callback);
    }

}

