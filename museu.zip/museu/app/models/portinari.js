module.exports = {
    getPaintings: (dbConnection, callback) => {

   dbConnection.query("select * from paintings where artista = 'Cândido Portinari' ", callback);
    }
}