module.exports = {
    getPainting: (dbConnection, id,callback) => {
        console.log("id no model", id)
     dbConnection.query("select * from paintings where idobra=" + id +";", callback);
        
      
    },

   
}



    