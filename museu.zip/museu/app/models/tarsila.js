module.exports = {
    getPaintings: (dbConnection, callback) => {

   dbConnection.query("select * from paintings where artista = 'Tarsila do Amaral' ", callback);
    }
}