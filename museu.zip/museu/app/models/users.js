module.exports = {

    addUser: (user, dbConnection, callback) => {
        const sql = `insert into users (email, password) VALUES ("${user.email}", "${user.password}");`
        console.log(sql);
        dbConnection.query(sql, callback);
    },

}

