module.exports = {

    addUser: (user, dbConnection, callback) => {
        const sql = `insert into users (email, password) VALUES ("${user.email}", "${user.password}");`
        console.log(sql);
        dbConnection.query(sql, callback);
    },
    authUser: (user, dbConnection, callback) => {
        const sql = `select * from users where email='${user.email}' AND password = '${user.password}';`
        console.log(sql);
        dbConnection.query(sql, callback);
    },
    
    
}

